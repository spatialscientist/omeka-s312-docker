<?php
namespace Omeka\Form\Element;

class ResourceClassSelect extends AbstractVocabularyMemberSelect
{
    public function getResourceName()
    {
        return 'resource_classes';
    }
}

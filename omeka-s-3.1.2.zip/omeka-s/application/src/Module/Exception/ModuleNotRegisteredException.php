<?php
namespace Omeka\Module\Exception;

class ModuleNotRegisteredException extends \RuntimeException implements ExceptionInterface
{
}

<?php
namespace Omeka\Mvc\Exception;

class InvalidJsonException extends RuntimeException
{
}

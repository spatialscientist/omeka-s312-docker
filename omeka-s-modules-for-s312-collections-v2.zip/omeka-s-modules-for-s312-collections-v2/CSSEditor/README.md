# CSSEditor

CSSEditor is a module for Omeka S that allows you to provide custom CSS overriding theme styles. You can also include URLs for external CSS, like those hosted by CDNs or used for webfonts.

See the [Omeka S user manual](http://omeka.org/s/docs/user-manual/modules/csseditor/) for user documentation.

## Installation

See general end user documentation for [Installing a module](http://omeka.org/s/docs/user-manual/install/)

<?php declare(strict_types=1);

namespace AdvancedSearch\View\Helper;

class FacetActive extends AbstractFacetElement
{
    protected $partial = 'search/facet-active';
}

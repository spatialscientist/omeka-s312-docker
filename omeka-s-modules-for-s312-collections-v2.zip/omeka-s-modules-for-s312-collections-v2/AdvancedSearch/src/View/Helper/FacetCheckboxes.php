<?php declare(strict_types=1);

namespace AdvancedSearch\View\Helper;

class FacetCheckboxes extends AbstractFacet
{
    protected $partial = 'search/facet-checkboxes';
}

<?php declare(strict_types=1);

namespace AdvancedSearch\View\Helper;

/**
 * @deprecated Since 3.3.6.4. Use FacetLinks instead.
 */
class FacetLink extends AbstractFacetElement
{
    protected $partial = 'search/facet-link';
}

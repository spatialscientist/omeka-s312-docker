<?php declare(strict_types=1);

namespace AdvancedSearch\View\Helper;

/**
 * @deprecated Since 3.3.6.4. Use FacetCheckboxes instead.
 */
class FacetCheckbox extends AbstractFacetElement
{
    protected $partial = 'search/facet-checkbox';
}
